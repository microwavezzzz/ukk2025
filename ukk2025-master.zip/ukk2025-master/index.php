<?php

header('Location: buku');
exit();
